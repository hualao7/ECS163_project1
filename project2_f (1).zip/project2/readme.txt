Project2 Milestone(the current index.html is in the "d3" file)

For the second project, I chose the dataset of "Louisville Government Employee Salaries".
I will create at least three charts of different interactive data visualization techniques to display the data and the analysis.

First I created a pie chart with a menu of choosing different department to display the data of employee salaries between the different period of years. I separate years between 2008 to current into three parts with each of three years. And by selecting the each different departments listed in the menu which is on the top of left, users can clearly read the actual employee salaries in each period of years. And based on the pie chart, the user can also know the ration between different year periods of the specific department. 

In my plan, then the user can click the pie chart to go to the second chart of a bar chart which can be sorted or organized to analysis salaries in the different department and different years. The bar chart will separate different types of employee salaries and do some calculation and combination to compare them.

Then for the third chart, I may use some bubble charts to show specific data of top 3 or 5 salaries in different years to help users to analysis some details of the dataset.

